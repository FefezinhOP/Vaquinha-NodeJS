module.exports = function (app) {

    const url = "https://oauth.livepix.gg/oauth2/token"

    const infos = {
        idcliente: '1fa819f5-4d19-4350-ab56-b9b22c19d37d',
        segredo: 'Qq6x9aQIP0rj3QKou5lx5K6as9hyKfvU7mSTmIinV9Uc3DeqyoV8pXrSu3MgmvJVRN7tQyOdm+9mQqhCjyzCRVdYA2bVPvI6AHiVQ64KuZQDB/xJDtL02zg2MxhWo2lz/En5Vis+lxKrJPuK4vMBW47l4SSyCvIC/1IuQKgottU',
        scopes: 'account:read, payments:read, messages:read, wallet:read'
    };

    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(infos),
    };

    app.get('/', function (req, res) {
        res.render('Vaquinha.ejs');
    });

    
}